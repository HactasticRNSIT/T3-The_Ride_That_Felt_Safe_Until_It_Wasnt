import { useState, useEffect } from "react";

const C = {
  bg: "#060d08", surface: "#0d1f10", card: "#111f14", border: "#1a3320",
  green: "#22c55e", amber: "#f59e0b", red: "#ef4444",
  text: "#f0fdf4", muted: "#6b7280", blue: "#60a5fa",
};

type Driver = { id: string; name: string; hermesh: number; signal: number; score: number; status: 'allocated' | 'eligible' | 'blocked' };
const DRIVERS: Driver[] = [
  { id: "D001", name: "Driver A", hermesh: 88, signal: 91, score: 89.4, status: "allocated" },
  { id: "D002", name: "Driver B", hermesh: 72, signal: 65, score: 69.4, status: "eligible" },
  { id: "D003", name: "Driver C", hermesh: 41, signal: 55, score: 47.4, status: "blocked" },
];

const OFFLINE_STATES: Record<string, { color: string; icon: string; label: string; sub: string }> = {
  BOTH_ONLINE:       { color: C.green, icon: "●", label: "Ride Active",              sub: "Dual GPS active · AI running · SafeCircle on standby" },
  PASSENGER_OFFLINE: { color: C.amber, icon: "◐", label: "Checking on you…",         sub: "SMS every 2 min · SafeCircle notified · Soft alert in 5 min" },
  DRIVER_OFFLINE:    { color: C.amber, icon: "◑", label: "Last known driver location",sub: "On-device ML continues · Haptic check-in sent" },
  BOTH_OFFLINE:      { color: C.red,   icon: "⚠", label: "3 Contacts Notified",      sub: "SOS SMS fired · Automated call · Platform flagged" },
};

const TABS = ["Booking", "Active Ride", "Offline States", "Heatmap"];

// ── Shared components ─────────────────────────────────────────────────────────

function ScoreBar({ value, color }: { value: number; color: string }) {
  return (
    <div style={{ background: C.border, borderRadius: 4, height: 6, overflow: "hidden" }}>
      <div style={{ width: `${value}%`, height: "100%", background: color, borderRadius: 4 }} />
    </div>
  );
}

function Badge({ status }: { status: 'allocated' | 'eligible' | 'blocked' }) {
  const cfg: Record<'allocated' | 'eligible' | 'blocked', { c: string; l: string }> = {
    allocated: { c: C.green, l: "Allocated" },
    eligible:  { c: C.amber,  l: "Eligible" },
    blocked:   { c: C.red,    l: "Blocked" },
  };
  const { c, l } = cfg[status];
  return <span style={{ padding: "3px 10px", borderRadius: 20, border: `1px solid ${c}`, color: c, fontSize: 12, fontWeight: 600, background: `${c}20` }}>{l}</span>;
}

// ── Screens ───────────────────────────────────────────────────────────────────

function BookingScreen() {
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 0" }}>
      <p style={{ color: C.green, fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>Smart Driver Allocation</p>
      <h1 style={{ color: C.text, fontSize: 36, fontWeight: 800, margin: "8px 0 4px" }}>Book Your Safe Ride</h1>
      <p style={{ color: C.muted, marginBottom: 28 }}>Drivers below SafeScore 60 are automatically blocked.</p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 24 }}>
        {DRIVERS.map(d => (
          <div key={d.id} onClick={() => d.status !== "blocked" && setSelected(d.id)}
            style={{ background: C.card, border: `1px solid ${selected === d.id ? C.green : C.border}`, borderRadius: 16, padding: 24, cursor: d.status !== "blocked" ? "pointer" : "default", opacity: d.status === "blocked" ? 0.45 : 1, position: "relative", transition: "border-color 0.2s" }}>
            {d.status === "allocated" && <div style={{ position: "absolute", top: 12, right: 12, background: C.green, color: "#000", fontSize: 10, fontWeight: 800, padding: "2px 8px", borderRadius: 20 }}>TOP MATCH</div>}
            <div style={{ fontSize: 28, marginBottom: 10 }}>🚗</div>
            <div style={{ color: C.text, fontWeight: 700, fontSize: 17, marginBottom: 6 }}>{d.name}</div>
            <div style={{ color: C.green, fontSize: 30, fontWeight: 800, marginBottom: 10 }}>{d.score}<span style={{ fontSize: 14, color: C.muted }}>/100</span></div>
            <Badge status={d.status} />
            <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 10 }}>
              {([["HerMesh", d.hermesh, C.green], ["SafeSignal", d.signal, C.blue]] as [string, number, string][]).map(([l, v, c]) => (
                <div key={l}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{ color: C.muted, fontSize: 12 }}>{l}</span>
                    <span style={{ color: c, fontSize: 12, fontWeight: 600 }}>{v}</span>
                  </div>
                  <ScoreBar value={v} color={c} />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div style={{ background: C.card, border: `1px solid ${C.green}`, borderRadius: 16, padding: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <p style={{ color: C.muted, fontSize: 13 }}>Selected driver · Ride will be silently monitored</p>
            <p style={{ color: C.text, fontWeight: 700, fontSize: 18, marginTop: 4 }}>
              {DRIVERS.find(d => d.id === selected)?.name} · <span style={{ color: C.green }}>{DRIVERS.find(d => d.id === selected)?.score}</span>
            </p>
          </div>
          <button style={{ background: C.green, color: "#000", border: "none", borderRadius: 12, padding: "14px 32px", fontWeight: 800, fontSize: 16, cursor: "pointer" }}>Confirm Ride →</button>
        </div>
      )}
    </div>
  );
}

function ActiveRideScreen() {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => { const t = setInterval(() => setElapsed(e => e + 1), 1000); return () => clearInterval(t); }, []);
  const mm = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const ss = String(elapsed % 60).padStart(2, "0");
  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 0" }}>
      <p style={{ color: C.green, fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>Layer 2 — Dual GPS Active</p>
      <h1 style={{ color: C.text, fontSize: 36, fontWeight: 800, margin: "8px 0 24px" }}>Active Ride Monitor</h1>

      <div style={{ background: C.card, border: `1px solid ${C.green}`, borderRadius: 16, padding: 28, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 12, height: 12, borderRadius: "50%", background: C.green, boxShadow: `0 0 10px ${C.green}` }} />
          <div>
            <p style={{ color: C.green, fontWeight: 700 }}>SafeMesh is watching</p>
            <p style={{ color: C.muted, fontSize: 13 }}>No action needed from you</p>
          </div>
        </div>
        <div style={{ color: C.text, fontFamily: "monospace", fontSize: 36, fontWeight: 800 }}>{mm}:{ss}</div>
        <div style={{ textAlign: "right" }}>
          <p style={{ color: C.muted, fontSize: 12 }}>SafeCircle</p>
          <p style={{ color: C.green, fontWeight: 700 }}>5 watching</p>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        {([
          ["Passenger GPS", "12.9716° N, 77.5946° E", C.green, "/rides/{rideId}/passenger_gps"],
          ["Driver GPS",    "12.9720° N, 77.5950° E", C.blue,  "/rides/{rideId}/driver_gps"],
        ] as [string, string, string, string][]).map(([l, coord, c, path]) => (
          <div key={l} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <div style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />
              <span style={{ color: c, fontWeight: 700 }}>{l}</span>
            </div>
            <p style={{ color: C.text, fontWeight: 600, marginBottom: 8 }}>{coord}</p>
            <p style={{ fontFamily: "monospace", fontSize: 12, color: C.muted, background: C.bg, padding: "6px 10px", borderRadius: 6 }}>{path}</p>
            <p style={{ color: C.muted, fontSize: 12, marginTop: 8 }}>Heartbeat: <span style={{ color: c }}>30s</span> · Status: <span style={{ color: C.green }}>Online</span></p>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
        {[["Route Deviation", "< 200m ✓"], ["Speed Anomaly", "Normal ✓"], ["GPS Spoofing", "None ✓"]].map(([l, v]) => (
          <div key={l} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 16, textAlign: "center" }}>
            <p style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>{l}</p>
            <p style={{ color: C.green, fontWeight: 700 }}>{v}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function OfflineScreen() {
  const [active, setActive] = useState("BOTH_ONLINE");
  const cfg = OFFLINE_STATES[active];
  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 0" }}>
      <p style={{ color: C.green, fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>Layer 3 — Offline Resilience</p>
      <h1 style={{ color: C.text, fontSize: 36, fontWeight: 800, margin: "8px 0 24px" }}>Escalation State Machine</h1>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
        {Object.keys(OFFLINE_STATES).map(k => (
          <button key={k} onClick={() => setActive(k)} style={{ padding: "8px 16px", borderRadius: 8, border: `1px solid ${active === k ? OFFLINE_STATES[k].color : C.border}`, background: active === k ? `${OFFLINE_STATES[k].color}20` : "transparent", color: active === k ? OFFLINE_STATES[k].color : C.muted, fontFamily: "monospace", fontSize: 13, cursor: "pointer", fontWeight: active === k ? 700 : 400 }}>{k}</button>
        ))}
      </div>

      <div style={{ background: C.card, border: `2px solid ${cfg.color}`, borderRadius: 20, padding: 48, textAlign: "center", transition: "border-color 0.4s" }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>{cfg.icon}</div>
        <p style={{ color: cfg.color, fontSize: 13, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>STATE → {active}</p>
        <h2 style={{ color: C.text, fontSize: 28, fontWeight: 800, marginBottom: 8 }}>{cfg.label}</h2>
        <p style={{ color: C.muted }}>{cfg.sub}</p>
        {active === "BOTH_OFFLINE" && (
          <div style={{ marginTop: 24, background: "#0a0000", border: `1px solid ${C.red}50`, borderRadius: 12, padding: 20, textAlign: "left", fontFamily: "monospace", fontSize: 13, color: "#fca5a5", lineHeight: 1.8, maxWidth: 480, margin: "24px auto 0" }}>
            <p style={{ color: C.red, marginBottom: 8 }}>▶ SafeMesh SOS Triggered</p>
            <p>✓ SMS fired to 3 SafeCircle contacts</p>
            <p>✓ Last GPS: 12.9716° N, 77.5946° E</p>
            <p>✓ Automated call attempt to passenger</p>
            <p>✓ Alert to nearest community watcher</p>
            <p style={{ marginTop: 16, paddingTop: 12, borderTop: `1px solid ${C.red}30` }}>
              [SafeMesh SOS] Ride anomaly detected.<br />
              Last known location: 12.9716° N, 77.5946° E.<br />
              Time: 22:41. Contact passenger immediately.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function HeatmapScreen() {
  const zones: { name: string; risk: 'high' | 'medium' | 'low'; reports: number }[] = [
    { name: "MG Road",     risk: "high",   reports: 34 },
    { name: "Majestic",    risk: "high",   reports: 28 },
    { name: "Koramangala", risk: "medium", reports: 17 },
    { name: "Rajajinagar", risk: "medium", reports: 12 },
    { name: "Whitefield",  risk: "low",    reports: 5 },
    { name: "HSR Layout",  risk: "low",    reports: 3 },
  ];
  const rc: Record<'high' | 'medium' | 'low', string> = { high: C.red, medium: C.amber, low: C.green };
  const pts: { x: number; y: number; r: number; risk: 'high' | 'medium' | 'low' }[] = [
    { x: 45, y: 35, r: 38, risk: "high" }, { x: 20, y: 42, r: 32, risk: "high" },
    { x: 63, y: 55, r: 25, risk: "medium" }, { x: 30, y: 62, r: 20, risk: "medium" },
    { x: 75, y: 28, r: 16, risk: "low" }, { x: 55, y: 75, r: 13, risk: "low" },
  ];
  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 0" }}>
      <p style={{ color: C.green, fontSize: 12, fontWeight: 600, letterSpacing: 2, textTransform: "uppercase" }}>B2G Licensing — Community Intelligence</p>
      <h1 style={{ color: C.text, fontSize: 36, fontWeight: 800, margin: "8px 0 24px" }}>Route Risk Heatmap</h1>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, overflow: "hidden", position: "relative", height: 400 }}>
          <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
            <rect width="100" height="100" fill={C.bg} />
            {[[10,10,90,10],[10,30,90,30],[10,50,90,50],[10,70,90,70],[10,90,90,90],[10,10,10,90],[30,10,30,90],[50,10,50,90],[70,10,70,90],[90,10,90,90]].map(([x1,y1,x2,y2],i) => (
              <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.border} strokeWidth="0.5" />
            ))}
            {pts.map((p, i) => (
              <g key={i}>
                <circle cx={p.x} cy={p.y} r={p.r / 9} fill={rc[p.risk] + "50"} stroke={rc[p.risk]} strokeWidth="0.4" />
                <circle cx={p.x} cy={p.y} r="1.5" fill={rc[p.risk]} />
              </g>
            ))}
          </svg>
          <div style={{ position: "absolute", top: 12, left: 12, background: "#00000090", borderRadius: 8, padding: "6px 12px" }}>
            <p style={{ color: C.green, fontWeight: 700, fontSize: 13 }}>Bengaluru</p>
            <p style={{ color: C.muted, fontSize: 11 }}>12.9716° N, 77.5946° E</p>
          </div>
          <div style={{ position: "absolute", bottom: 12, right: 12, display: "flex", gap: 8 }}>
            {[["High", C.red], ["Medium", C.amber], ["Low", C.green]].map(([l, c]) => (
              <div key={l} style={{ display: "flex", alignItems: "center", gap: 4, background: "#00000090", padding: "4px 8px", borderRadius: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: c }} />
                <span style={{ color: C.text, fontSize: 11 }}>{l}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {zones.map(z => (
            <div key={z.name} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: rc[z.risk] }} />
                <span style={{ color: C.text, fontWeight: 600, fontSize: 14 }}>{z.name}</span>
              </div>
              <span style={{ color: C.muted, fontSize: 12 }}>{z.reports}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState("Booking");
  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", color: C.text }}>
      <style>{`* { box-sizing: border-box; margin: 0; padding: 0; } body { background: ${C.bg}; }`}</style>
      {/* Navbar */}
      <nav style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "0 32px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64, position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: `linear-gradient(135deg, ${C.green}, #166534)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>⬡</div>
          <span style={{ color: C.text, fontWeight: 800, fontSize: 20 }}>Safe<span style={{ color: C.green }}>Mesh</span></span>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ padding: "8px 18px", borderRadius: 8, border: "none", cursor: "pointer", background: tab === t ? C.green : "transparent", color: tab === t ? "#000" : C.muted, fontWeight: tab === t ? 700 : 400, fontSize: 14 }}>{t}</button>
          ))}
        </div>
        <div style={{ color: C.green, fontSize: 20 }}>♀</div>
      </nav>
      {/* Page */}
      <div style={{ padding: "0 32px" }}>
        {tab === "Booking"       && <BookingScreen />}
        {tab === "Active Ride"   && <ActiveRideScreen />}
        {tab === "Offline States"&& <OfflineScreen />}
        {tab === "Heatmap"       && <HeatmapScreen />}
      </div>
    </div>
  );
}
